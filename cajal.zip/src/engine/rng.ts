/**
 * rng.ts — Generador de números pseudoaleatorios determinista (Mulberry32)
 * Permite partidas 100% reproducibles para TDD, replay y verificación científica.
 */

export function mulberry32(seed: number): () => number {
  let s = seed | 0;
  return function () {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
